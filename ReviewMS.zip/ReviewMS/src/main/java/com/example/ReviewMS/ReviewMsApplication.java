package com.example.ReviewMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewMsApplication.class, args);
	}

}
